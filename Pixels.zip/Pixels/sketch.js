// sketch.js

let photo;

function preload() {
  photo = loadImage("Yosemite_800.jpg");
}

function setup() {
  createCanvas(800, 520);
  photo.loadPixels();
}

function draw() {
  background(128);

  /*
  let colorRed = color(255,0,0);
  fill(colorRed);
  ellipse(200,200,50,50);
  let colorGreen = color(0,255,0);
  fill(colorGreen);
  ellipse(300,200,50,50);
  let colorBlue = color(0,0,255);
  fill(colorBlue);
  ellipse(400,200,50,50);
  */
  
  image(photo,0,0);

  
  let pixelColor = photo.get(mouseX,mouseY);
  fill(pixelColor);
  noStroke();
  rectMode(CENTER);
  rect(400,266,200,200);
  

  //drawImageByPixel_V1();
  //drawImageByPixel_V2();

  //matrixUsingAverages();

  //noLoop();
}

function drawImageByPixel_V1() {
  let startTime = millis();
  let y = 0;
  noStroke();
  while (y < photo.height) {
    let x = 0;
    while (x < photo.width) {
      let pixelColor = photo.get(x,y);
      fill(pixelColor);
      rect(x,y,1,1);
      x += 1;
    }
    y += 1;
  }
  let stopTime = millis();
  let duration = (stopTime - startTime) / 1000.0;
  print("duration = " + duration);
}

function drawImageByPixel_V2() {
  let startTime = millis();
  let y = 0;
  noStroke();
  
  while (y < photo.height) {
    let x = 0;
    while (x < photo.width) {
      let index = (y * photo.width * 4) + x * 4;
      let r = photo.pixels[index];
      let g = photo.pixels[index+1];
      let b = photo.pixels[index+2];
      fill(r,g,b);
      rect(x,y,1,1);
      x += 1;
    
    }
    y += 1;
  }
  let stopTime = millis();
  let duration = (stopTime - startTime) / 1000.0;
  print("duration = " + duration);
}

function averageColorInRect(px,py,pw,ph) {
  let avgr = 0;
  let avgg = 0;
  let avgb = 0;
  let y = py;
  let count = 0;
  noStroke();
  while (y < py + ph) {
    let x = px;
    while (x < px + pw) {
      let index = (y * photo.width * 4) + x * 4;
      let r = photo.pixels[index];
      let g = photo.pixels[index+1];
      let b = photo.pixels[index+2];
      avgr += r;
      avgg += g;
      avgb += b;
      x += 1;
      count += 1;
    }
    y += 1;
  }
  
  avgr /= count;
  avgg /= count;
  avgb /= count;
  print(avgr + ", " + avgg + ", " + avgb);
  return color(avgr, avgg, avgb, 255);
}

function matrixUsingAverages() {
  let y = 0;
  let w = 40;
  let h = 40;
  noStroke();
  rectMode(CORNER);
  while (y < height) {
    let x = 0;
    while (x < width) {
      let avgColor = averageColorInRect(x,y,w,h);
      fill(avgColor);
      rect(x,y,w,h);
      x += w;
    }
    y += h;
  }
}
